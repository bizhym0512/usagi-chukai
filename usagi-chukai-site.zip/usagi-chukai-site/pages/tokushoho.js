export default function Tokushoho() {
  return (
    <div style={styles.container}>
      <h1>特定商取引法に基づく表記</h1>

      <p>※ここに特商法の全文を貼り付けてください。</p>

    </div>
  );
}

const styles = {
  container: {
    maxWidth: "800px",
    margin: "0 auto",
    padding: "40px 20px",
    lineHeight: 1.8,
    fontFamily: "sans-serif",
  },
};
